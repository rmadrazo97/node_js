var http = require('http');
var async = require('async');

//arguments passed by 1 and 2
var hostname = process.argv[2];
var port = process.argv[3];
var url = 'http://' +  hostname + ':' + port;

async.series({
  post: function(done){
    async.times(5, function(n, next){
      _addUser(++n, function(err){
        next(err);
      });
    }, function next(err){
      if (err) return done(err);
      done(null, 'saved');
    });
  },

  get: function(done){
    http.get(url + '/users', function(res){
      var bd = "";
      res.on('data', function(chunk){
        bd += chunk.toString();
      });

      res.on('end', function(){
        done(null, bd);
      });
    }).on('error', done);
  }

}, function done(err, result){
  if (err) return console.log(err);
  console.log(result.get);
});


function _addUser(user_id, next){
  var postdata = JSON.stringify({'user_id': user_id}),
  opts = {
    hostname: hostname,
    port: port,
    path: '/users/create',
    method: 'POST',
    headers: {
      'Content-Length': postdata.length
    }
  };

  var req = http.request(opts, function(res){
    res.on('data', function(chunk){})

    res.on('end', function(){
      next();
    });
  });

  req.on('error', function(err){
    next(err);
  });

  req.write(postdata);
  req.end();
}