var http = require('http');
var async = require('async');

// async.each, -> results get lost.
//async.map, collects results inside an array.
async.map(process.argv.slice(2, 4), function (item, done) {
  http.get(item, function (res) {
    var bd = '';
    res.on('data', function (chunk) {
      bd += chunk.toString();
    });

    res.on('end', function () {
      done(null, bd);
    });
  }).on('error', function (err) {
    done(err);
  });
}, function (err, results) {
  if (err) {
    return console.error(err);
  }

  console.log(results);
});