// series collect all results as array. 
//async.series -> object, where we can asign properties. 

//require dependencies. 
var http = require('http');
var async = require('async');

async.series({
    requestOne: function (cb) {
        //get 1 arg.
      http.get(process.argv[2], function (res) {
        var body = '';
        res.on('data', function (chunk) {
          body += chunk.toString();
        }).on('end', function () {
          cb(null, body);
        });
      }).on('error', function (err) {
        return cb(err);
      });
    },
  
    requestTwo: function (cb) {
        //get 2nd arg. 
      http.get(process.argv[3], function (res) {
        var body = '';
        res.on('data', function (chunk) {
          body += chunk.toString();
        }).on('end', function () {
          cb(null, body);
        });
      }).on('error', function (err) {
        return cb(err);
      });
    }
  }, function (err, result) {
    if (err) {
      return console.error(err);
    }
  
    console.log(result);
  });