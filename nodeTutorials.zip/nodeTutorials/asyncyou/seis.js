// get libraries
var http = require('http');
var async = require('async');

// url as 1 argument in http
var url = process.argv[2];

// for each value, send a GET using http.get
async.reduce(['one', 'two', 'three'], 0, function (memo, item, cb) {
  //numbers pass to http.get
  //must prin out, the number passed by. 
    http.get(url + '?number=' + item, function (res) {
    var bd = '';
    res.on('data', function (chunk) {
      bd += chunk.toString();
    });

    res.on('end', function () {
      cb(null, memo + parseInt(bd, 10));
    });
  }).on('error', function (err) {
    return console.error(err);
  });
}, function (err, result) {
  if (err) {
    return console.error(err);
  }

  console.log(result);
});