var http = require('http');
var async = require('async');

var requestBody = '';

var nrequests = 0;

async.whilst(
  function() {
    return !/meerkat/.test(requestBody.trim());
  },

  function(done){
    var body = '';
    // first cm line arg
    http.get(process.argv[2], function(res){
      res.on('data', function(chunk){
        body += chunk.toString();
      });

      res.on('end', function(){
          // on request end ++ one more request to retrieve meerkat.
        ++nrequests;
        requestBody = body;
        done();
      });
    }).on('error', done);
  },

  function(err){
    if (err) return console.log(err);
    console.log(nrequests);
  }
)