//import libraires.
var http = require('http');
var async = require('async');

//calling same function multipletimes w different inputs. 
//asyn.each -> makes this. 

// gets 3 calls and slices them. for each, cm arguments call the function.

async.each(process.argv.slice(2), function(item, done){
  http.get(item, function(res){
    res.on('data', function(chunk){
    });

    res.on('end', function(){
      done(null);
    });
  }).on('error', function(err){
    done(err);
  });
},
function(err){
  if(err) console.error(err);
});