
//require dependencies. 
var http = require('http');
var fs = require('fs');
var async = require('async');

//filename comes in the 1st argument. 
var filename = process.argv[2];

async.waterF([
  function (cb) {
    fs.readFile(filename, 'utf-8', function (err, data) {
      if (err) {
        return cb(err);
      }

      cb(null, data);
    });
  },

  function (data, cb) {
    var body = '';

    http.get(data, function (res) {
      res.on('data', function (chunk) {
        body += chunk.toString();
      })
      .on('end', function () {
        cb(null, body);
      });
    })
    .on('error', function (err) {
      cb(err);
    });
  }
], function (err, result) {
    
    if (err) {
      return console.error(err);
    }

    console.log(result);
});
