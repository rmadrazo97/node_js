var pizza = {
        toppings:['cheese', 'sauce','pepperoni'],
        crust: 'deep dish',
        serves: 2
};

var heladin = {
        toppings:['mania', 'chocolate','rice crispies'],
        flavour: 'CHOCOLATE',
        serves: 2
};
console.log(pizza);
console.log(heladin);