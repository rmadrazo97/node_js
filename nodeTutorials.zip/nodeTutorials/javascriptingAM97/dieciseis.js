function eat (food){
        return food + " tasted awful.";
}
console.log(eat('bananas'));