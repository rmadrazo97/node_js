function math (arg1, arg2, arg3,arg4){
        return ((arg2*arg3)+arg1)/arg4;
}
console.log(math(53,61,67,2));
