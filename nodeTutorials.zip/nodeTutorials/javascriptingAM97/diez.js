
//mi codigguin ::)))))
var total = 0; 
var limit = 45;
for (var i = 0;i < limit;i++){
    total +=1;
}
console.log(total);