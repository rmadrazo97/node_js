var food = ['apple', 'pizza','pear','pie','popcorn'];
console.log(food[1]);