var numbers = [1,2,3,4,5,6,7,8,9,10,20,40,50,60];
var filtered = numbers.filter(function evenNumbers (number){
    return(number % 10 == 0 );
    // multiplos de 10 y 10 mismo. 
});
console.log(filtered);