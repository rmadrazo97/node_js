var food = {
        types: 'only pizza',
        flavours:['pepperoni', 'ham']
};
console.log(food.types);
console.log(food.flavours);