var pets = ['gat', 'perr', 'rat'];
for (i = 0 ; i < pets.length; i++){
        //console.log(pets[i]);
        pets[i]=pets[i]+'ita';
}
console.log(pets);
