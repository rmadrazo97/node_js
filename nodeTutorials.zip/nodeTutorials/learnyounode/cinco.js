// require fs first. 
// file system.
// api to interact with file system.
var fs = require('fs');

// path to dir.
// 2 -first argument
var dir = process.argv[2];

// 3 -second arugment
var extension = process.argv[3];

// type of extension to filter. 
var ext2filter = new RegExp('\\.'+extension+'$');

fs.readdir(dir,function(err,list){
        list.forEach(function(item){
                if(ext2filter.test(item)){
                        console.log(item)
                }
        })
})