// require fs first. 
// file system.
// api to interact with file system.
var fs = require('fs');
// getting path to the file to read from. 
//full path to the file to read.
// process.argv returns an array containing the command line arguments when node.js is launched. 
// 2nd element is the path to the js file being executed.
fs.readFile(process.argv[2],'utf8', function (err, data){
        console.log(data.split('\n').length - 1 )
        // get num of \n - 1
        // utf8 to avoid passing it to .toString()
});