//listen to a TCP connection, on the port provided on the 1st argument. 
//for each conn -> write a current date & 24 hr time
//  format> yyyy-mm-dd hh:mm

//import net module.
var net = require("net");

// incomming port. 
var port = process.argv[2];

//date object.
var date = new Date();
var year = date.getFullYear();
//months are 0 indexed in js. then month +1 
var month = date.getMonth()+1;
var day = date.getDate();
var hour = date.getHours();
var minutes = date.getMinutes();

// getting the 01,02...09 format. 
if(month < 10){
    month = "0" + month;
}
if (day < 10){
    day = "0" + day;
}
if (hour < 10){
    hour = "0" + hour;
}
if (minutes < 10){
    minutes = "0" + minutes;
}

// getting it all together. 
var datef = year + "-" + month + "-" + day + " " + hour + ":" + minutes+ "\n";


var server = net.createServer(function listener(socket){
    socket.end(datef);
})
// socket.write(data)
//  writes data to the socket.
//socket.end()
//  close socket.
server.listen(port);
