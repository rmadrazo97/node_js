//http upercaser
//receives post and converts them to uppercase
//  returns to client. 

var http = require("http");
//incomind port in cm line. arg1
var port = process.argv[2];
//cunch character reverser.
var map = require("through2-map");

var srv = http.createServer(function callback(req, res){
    // if its a post....
    if(req.method = 'POST'){
        req.pipe(map(function(chunk){
            return chunk.toString().toUpperCase()
        })).pipe(res);
    }
})

//listen to port. 
srv.listen(port);