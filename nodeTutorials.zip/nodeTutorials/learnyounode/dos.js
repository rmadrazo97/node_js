
var sum = 0;
var multi = 1;
process.argv.slice(2).forEach(function(arg){

        sum +=  + arg;
        multi = multi * arg;

});
console.log(sum);
console.log(multi)