//require http module. 
var http = require('http');
//takes urls as arugments
//starting grom 2 up to 4
var urls = [process.argv[2],process.argv[3],process.argv[4]];

// array to keep data ordered.
var datar = [];
var i = 0;

function httpOrdered(url, round ){

    http.get(url, function callback(response){
        //variable to store data.
        var datat = "";

        //print in the same order provided. 2,3,4
        //make it a string.
        response.setEncoding("utf8");
        //listening for data event.
        response.on("data", function(data){
            datat = datat + data;
        })
        //listen for end event
        // when all data is collected.... print all per line. 
        response.on("end", function(){
            // important to keep order. 
            // async...
            // check (i) who many times it has ran. 
            //push things in order. 
            // if : i = 2 log datar

            datar[round] = datat;

            if (i == 2){
                // print data, one by one. 
                printloop();

            }
            // else not done yet.
            else{
                i++;
            }
        })
    })
}
// run the foor loop for every url provided in the cm line. 
for (var e = 0; e < urls.length;e++ ){
    httpOrdered(urls[e],e);
}

function printloop(){
    for (var o = 0; o < datar.length; o++){
        console.log(datar[o]);
    }
}