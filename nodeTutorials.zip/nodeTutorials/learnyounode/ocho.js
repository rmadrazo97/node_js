//http collect.
//http GET request to a URL provided as the 1st cm line argument. 
//collect all and write 2 lines stdout. 
//  1line> int representing num of characters.
//  2line> complete string sent by the server.

var http = require('http');
// url provided as the first argument. via commandline
var url = process.argv[2];
var datat = "";
//get request. 
http.get(url, function callback(response){
    //reponse object node stream object.
    //emit strings. 
    response.setEncoding("utf8"); 
    response.on("data", function(data){
            datat = datat + data;
    });
    //listen to end event and when done... print
    response.on("end", function(){
        //data length
        console.log(datat.length);
        // total data
        console.log(datat);
    })
    
}
);