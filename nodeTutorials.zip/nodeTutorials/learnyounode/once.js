//ttp server
//same txt for each request. 
//fs.createReadStream()

//require http n filesystem
var http = require('http');
var fs = require ('fs');

// 1 cm line arugment port
var port = process.argv[2];

// location of the file to serve. 
var file2Serve = process.argv[3];

// callback.
var srv = http.createServer(function callback(req, res){
    //objects request, response
    // node streams. 
    var readS = fs.createReadStream(file2Serve);
    // pipe data from src to dst. source -> destination.
    readS.pipe(res);
})

srv.listen(port);