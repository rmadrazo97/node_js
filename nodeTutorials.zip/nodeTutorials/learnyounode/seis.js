//same as cinco.js
var dir = process.argv[2];
//
var extension=process.argv[3];
//

require('/dir2')(dir,extension,function(err,data){
        if (err){
                return console.error(err)
        }
        //for each occurency, print a line. 
        data.forEach(function(item) {
                console.log(item);
        })
});