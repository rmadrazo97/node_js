
//getting directory and extension
var dir = process.argv[2];
var extension = process.argv[3];

// calling it as a function. 
require('./modular.js')(dir, extension, function (err, data) {
	if (err) {
		return console.error(err)
	}

	data.forEach(function (item) {
		console.log(item);
	})
})
