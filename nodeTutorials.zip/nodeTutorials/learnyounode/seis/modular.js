// single funciton export.
// takes callback function as argument. 
// if main imports this export, it should print "equis"

//requiere fs and path
var fs = require('fs');

module.exports = function(dir2, extension2, cb){
        var results = [];
        var ext2Filter = new RegExp('\\.' + extension2 + '$');
        
        fs.readdir(dir2, function (err, list) {
                if (err){
                  return cb(err)
                }
                list.forEach(function (item) {
                  if (ext2Filter.test(item)){
                    results.push(item)
                  }
                })
                cb(null, results);
              })
        //var x = "equis";
        //callback(x);
}