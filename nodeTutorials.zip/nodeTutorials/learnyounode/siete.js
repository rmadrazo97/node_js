var http = require('http');
// url provided as the first argument. via commandline
var url = process.argv[2];

//get request. 
http.get(url, function callback(response){
        //reponse object node stream object.
        //emit strings. 
        response.setEncoding("utf8"); 
        response.on("data", function(data){
                console.log(data);
        });
}
);