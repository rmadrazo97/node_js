//http json api server. 
//

var http = require("http");
//incoming url.
var url = require("url");

var srv = http.createServer(function(req,res){
    // get request.
    // verify path. 
    if(req.method == "GET"){
        //console.log("HI")
        var parsedUrl = url.parse(req.url, true);
        //console.log(parsedUrl.path);
        var path = parsedUrl.path;

        var date = new Date(parsedUrl.query.iso);

        // >=0 lo leyo
        if(path.indexOf("parsetime")>= 0){
            //get date. -> to json
            var result = {
                hour: date.getHours(),
                minute: date.getMinutes(),
                second: date.getSeconds()
            }
            res.end(JSON.stringify(result))
        }
        if(path.indexOf("unixtime")>= 0){
            var result = {"unixtime": date.getTime()}
            res.end(JSON.stringify(result))
        }
    }

})

srv.listen(process.argv[2])