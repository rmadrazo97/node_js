// require fs library
var fs = require('fs');
//full path to the file to read.
// process.argv returns an array containing the command line arguments when node.js is launched. 
// 2nd element is the path to the js file being executed.

var file = process.argv[2];
// save in the buffer the file read by fs, located in file's path given by argv. 
var buffer = fs.readFileSync(file, 'utf8');
// count number of '\n's in the file by saving them into a splited array. 
var n = buffer.split('\n').length
// n-1 not n 
console.log(n-1);